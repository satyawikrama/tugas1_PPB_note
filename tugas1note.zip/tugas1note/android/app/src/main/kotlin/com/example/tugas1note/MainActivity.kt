package com.example.tugas1note

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
